<template>
    <div class="container text-center">
        esta es la página de inicio
    </div>
</template>

<script>
export default {
  name: 'Main'
}
</script>
