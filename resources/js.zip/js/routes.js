import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

// Pages
import Home from './views/Home'
// import Combos from './views/Combos'
// import Contact from './views/Contact'
// import Login from './views/Login'
// import Logout from './views/Logout'
// import Dashboard from './views/Dashboard'

// Routes
const router = new VueRouter({
    mode: 'history',
    linkActiveClass: 'is-active',
    routes: [
        {
            path: '/',
            name: 'Home',
            component: Home,
        },
        {
            path: '*', 
            redirect: '/', 
        },
    ],
});

export default router