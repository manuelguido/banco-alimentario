<template>
    <h3 class="h6 black-b display-inline m-0">{{title}}</h3>
</template>

<script>
    export default {
        props: {
            title: String
        }
    }
</script>
