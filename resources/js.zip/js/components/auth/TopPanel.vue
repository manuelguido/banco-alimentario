<template>
    <div class="col-12 text-center my-lg-4">
        <h1 class="h3 black-b">{{title}}</h1>
    </div>
</template>

<script>
    export default {
        props: {
            title: String
        }
    }
</script>
