// import axios from 'axios'

import Home from '.././views/Home'

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  }
]

export default routes
